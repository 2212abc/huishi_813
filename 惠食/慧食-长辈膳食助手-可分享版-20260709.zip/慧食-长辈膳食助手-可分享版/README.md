# 慧食·长辈膳食助手 可分享版

这是一个可本地运行的前端 Demo，包含长辈端、家人端、健康档案、语音记餐、拍照识别、周报和家人绑定演示。

当前分享版的“拍一拍”会使用内置样例饭菜照片演示识别流程，点击 `打开手机相册` 后会展示样例照片并给出饮食建议，便于没有相册权限的浏览器也能完整演示。

## 最简单打开方式

双击 `index.html` 可以直接预览页面。

但如果要测试手机拍照、麦克风权限、图片识别代理接口，建议用本地服务方式打开。

## 本地服务方式

电脑需要安装 Node.js 18 或更高版本。

macOS：

1. 双击 `start.command`
2. 浏览器打开 `http://127.0.0.1:8787/`

Windows：

1. 双击 `start.bat`
2. 浏览器打开 `http://127.0.0.1:8787/`

手动启动：

```bash
node server.js
```

默认地址是 `http://127.0.0.1:8787/`，如果端口被占用，可以这样换端口：

```bash
PORT=8789 node server.js
```

## 手机测试

电脑和手机连接同一个 Wi-Fi。

1. 在电脑上启动本地服务
2. 查看电脑局域网 IP
3. 手机浏览器访问 `http://电脑IP:8787/`

注意：部分手机浏览器要求 HTTPS 才能完整开放麦克风/摄像头权限。演示阶段可先用电脑浏览器或手机本地预览工具测试。

## 大模型接口配置

不要把真实 key 写进前端文件。

复制 `.env.example` 为 `.env`，然后填入自己的 key：

```bash
OMINIGATE_API_KEY=你的key
OMINIGATE_BASE_URL=https://api.ominigate.ai/v1
OMINIGATE_TEXT_MODEL=openai/gpt-4o-mini
OMINIGATE_VISION_MODEL=openai/gpt-4o
OMINIGATE_PHOTO_MEAL_MODEL=openai/gpt-4o
OPENROUTER_API_KEY=你的OpenRouter key
OPENROUTER_BASE_URL=https://openrouter.ai/api/v1
OPENROUTER_PHOTO_MEAL_MODEL=openai/gpt-5.5
```

配置后重启 `server.js`：

- 语音/文字记餐会优先走 `/api/analyze-voice-meal`
- 拍照识别会优先走 OpenRouter `/api/analyze-photo-meal`，模型默认 `openai/gpt-5.5`
- 拍照结果会返回食物清单、每 100g 热量、估算份量/热量，并结合慢病和过敏史给简短建议
- 图片基础识别仍保留 `/api/analyze-photo`
- 如果接口不可用，前端会自动回退到本地保守判断

## 文件说明

- `index.html`：页面结构
- `styles.css`：视觉样式
- `app.js`：交互、语音、拍照、本地判断逻辑
- `server.js`：本地静态服务和图片识别代理
- `assets/logo.png`：应用 logo
- `assets/demo-meal.jpg`：拍照识别样例饭菜照片
- `.env.example`：大模型配置模板
